## How to run
1. Install requirements: `pip install -r requirements.txt`
2. Run the script: `bash run.sh`
3. Go to `http://localhost:5000`


Dos on me BROWSER:
while true; do   echo -ne "[*] Request $i\r";   curl -s http://127.0.0.1:5000/any-api-call > /dev/null;   ((i++)); done

$i = 0
while ($true) {
    Write-Host "[*] Request $i" -NoNewline
    curl http://127.0.0.1:5000/any-api-call > $null
    $i++
}




Dos on me API:
while true; do   echo -ne "[*] Request $i\r";   curl -X GET http://127.0.0.1:5000/any-api-call      -H "Accept: application/json"      -v;  > /dev/null;   ((i++)); done


$i = 0
while ($true) {
    Write-Host "[*] Request $i" -NoNewline
    curl -H "Accept: application/json" http://127.0.0.1:5000/any-api-call > $null
    $i++
}


