import time
import sys
import os

# Add app to path
sys.path.append(os.getcwd())

from app.config import Config
# Monkeypatch Config for testing
Config.CAPACITY = 5
Config.RATE = 10 
Config.BAN_THRESHOLD = 2
Config.BAN_DURATIONS = [2, 4, 6]
Config.TIME_WINDOW = 2

from app.services.token_bucket import TokenBucket
from app.services.redis_service import redis_conn

def test_escalation():
    print("Starting Escalation Test...")
    bucket = TokenBucket(10)
    key = "test_user_1"
    
    # Clear previous state
    redis_conn.delete(f"bucket:{key}", f"ban:{key}", f"strikes:{key}", f"violations:{key}")

    for stage in range(3):
        print(f"\n--- Stage {stage + 1} ---")
        # Trigger Ban
        print("Triggering ban...")
        # Force strikes
        for i in range(10): 
            allowed, remaining, retry = bucket.consume(key, cost=100) # Ensure cost > capacity
            if not allowed and retry > 0:
                print(f"Banned! Retry after: {retry}")
                expected_duration = Config.BAN_DURATIONS[stage]
                
                # Check if retry is close to expected (allow small execution time diff)
                if abs(retry - expected_duration) < 1.0:
                    print(f"SUCCESS: Duration matches {expected_duration}s")
                else:
                    print(f"FAILURE: Expected ~{expected_duration}s, got {retry}s")
                break
            time.sleep(0.1)
        
        # Wait for ban to expire
        wait_time = Config.BAN_DURATIONS[stage] + 1
        print(f"Waiting {wait_time}s for ban to expire...")
        time.sleep(wait_time)
        
        # Verify unbanned
        if bucket.is_banned(key):
             print("FAILURE: Still banned after expiration!")
        else:
             print("SUCCESS: Unbanned after expiration.")

if __name__ == "__main__":
    try:
        test_escalation()
    except Exception as e:
        print(f"Error: {e}")
        import traceback
        traceback.print_exc()
