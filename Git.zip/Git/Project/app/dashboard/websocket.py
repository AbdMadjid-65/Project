import json
from fastapi import WebSocket

# WebSocket is dual connection line between the client and the server not like req and res

class ConnectionManager:
    def __init__(self):
        self.active_connections: list[WebSocket] = []
        
    async def connect(self, websocket: WebSocket): # when client try to connect  
        await websocket.accept() # accept the connection
        self.active_connections.append(websocket) # add it to the web socket 


    def disconnect(self, websocket: WebSocket):
        if websocket in self.active_connections:
            self.active_connections.remove(websocket)

    # To prevent sending response to unavailable user 

    async def broadcast(self, data: dict): # when we need to send data to all connected user 

        payload = json.dumps(data) # change the data format do json

        for websocket in self.active_connections: # use this loop to pass over all connected user and send for them this data 
            try:
                await websocket.send_text(payload)
            except Exception:
                self.disconnect(websocket)

    @property
    def count(self): # number of the current connected user 
        return len(self.active_connections)

ws_manager = ConnectionManager() # any update (add user delete user brodcast ) to the websoket use this object 
