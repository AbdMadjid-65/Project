import traceback
from fastapi import Request
from fastapi.responses import JSONResponse
from starlette.middleware.base import BaseHTTPMiddleware

from app.config import Config
from app.middleware.fingerprint import generate_fingerprint
from app.services.token_bucket import TokenBucket
from app.services.firewall import firewall_manager


class RateLimiterMiddleware(BaseHTTPMiddleware):

    BYPASS_PATHS = {"/", "/favicon.ico", "/ws/stats"}
    BYPASS_PREFIXES = ("/static",)

    def __init__(self, app, broadcast_fn=None):
        super().__init__(app)
        self.api_bucket = TokenBucket(Config.API_RATE_LIMIT)
        self.browser_bucket = TokenBucket(Config.BROWSER_RATE_LIMIT)
        self.broadcast_fn = broadcast_fn  

    async def dispatch(self, request: Request, call_next):
        path = request.url.path
        # if the request on paths with no constrains allow to pass
        if path in self.BYPASS_PATHS or any(path.startswith(p) for p in self.BYPASS_PREFIXES):
            return await call_next(request)

        try:
            ip = request.client.host # Extracting the ip ....
            ua = request.headers.get("user-agent", "")
            auth = request.headers.get("authorization", "")
            fingerprint = generate_fingerprint(ip, ua, auth) # creat the fingerprint 

            # To identify the type of the request api or browser 
            accept = request.headers.get("accept", "")
            is_api = "application/json" in accept
            request_type = "API" if is_api else "Browser"

            bucket = self.api_bucket if is_api else self.browser_bucket
            key = f"{request_type.lower()}:{fingerprint}"

            allowed, remaining, retry_after = bucket.consume(key)

            event = {
                "ip": ip,
                "path": path,
                "type": request_type,
                "protocol": "HTTP",
                "blocked": not allowed,
                "remaining": remaining,
            }
            if self.broadcast_fn:
                try:
                    await self.broadcast_fn(event)
                except Exception:
                    pass

            if not allowed:
                # if bucket.is_banned(key):
                #     firewall_manager.block_ip(ip)

                return JSONResponse(
                    status_code=429,
                    content={
                        "error": "Too Many Requests",
                        "type": request_type,
                        "retry_after": retry_after,
                    },
                    headers={"Retry-After": str(int(retry_after))},
                )

            response = await call_next(request)
            response.headers["X-Sentinel-Remaining"] = str(remaining)
            response.headers["X-Sentinel-Type"] = request_type
            return response

        except Exception as e:
            print("--- SENTINEL MIDDLEWARE ERROR ---")
            traceback.print_exc()
            return JSONResponse(status_code=500, content={"error": str(e)})
