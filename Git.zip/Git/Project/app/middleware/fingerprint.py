import hashlib
from app.config import Config

SECRET_KEY = Config.SECRET_KEY

def generate_fingerprint(ip: str, user_agent: str = "", auth_header: str = "") -> str:
    raw = f"{ip}|{user_agent}|{auth_header}|{SECRET_KEY}" # concatinate the string and separet between them with | 
    return hashlib.sha256(raw.encode("utf-8")).hexdigest()[:16]
