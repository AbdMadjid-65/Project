import time
from app.config import Config
from app.services.redis_service import redis_conn


class TokenBucket:
    def __init__(self,RATE_LIMIT):
        self.capacity = Config.CAPACITY
        self.RATE = Config.RATE
        self.ban_threshold = Config.BAN_THRESHOLD
        self.ban_duration = Config.BAN_DURATION
        self.RATE_LIMIT=RATE_LIMIT
        self.TIME_WINDOW=Config.TIME_WINDOW

    def consume(self, key: str, cost: int = 1) -> tuple: # cost is how much the request consume  token 
        ban_key = f"ban:{key}"
        bucket_key = f"bucket:{key}"
        strikes_key = f"strikes:{key}"

        if redis_conn.exists(ban_key): # if the user is banned return ... 
            ttl = redis_conn.ttl(ban_key)
            retry_after = max(ttl, 1)
            return False, 0, float(retry_after)

        now = time.time()
        data = redis_conn.hgetall(bucket_key)

        if not data:
            tokens = self.capacity - cost
            last_fill = now
        else:
            last_fill = float(data.get("last_fill", now))
            tokens = float(data.get("tokens", self.capacity))

            elapsed = now - last_fill
            tokens = min(self.capacity, tokens + elapsed * self.RATE)

            tokens -= cost
            last_fill = now

        if tokens < 0:
            strikes = redis_conn.incr(strikes_key)
            redis_conn.expire(strikes_key, self.TIME_WINDOW)

            if strikes >= self.ban_threshold:
                violations_key = f"violations:{key}"
                violation_count = redis_conn.incr(violations_key)
                redis_conn.expire(violations_key, 86400) # Reset escalation after 24h

                durations = Config.BAN_DURATIONS
                index = min(violation_count - 1, len(durations) - 1)
                duration = durations[index]

                redis_conn.set(ban_key, "1", ex=duration)
                redis_conn.delete(strikes_key)

            retry_after = max(cost / self.RATE, 1.0)
            return False, 0, retry_after

        redis_conn.hmset(bucket_key, {"tokens": tokens, "last_fill": last_fill})
        redis_conn.expire(bucket_key, 3600)
        redis_conn.delete(strikes_key)

        return True, int(tokens), 0.0

    def is_banned(self, key: str) -> bool:
        return redis_conn.exists(f"ban:{key}")

    def unban(self, key: str):
        redis_conn.delete(f"ban:{key}")

    def get_all_bans(self) -> list:
        ban_keys = redis_conn.keys("ban:*")
        return [k.replace("ban:", "", 1) for k in ban_keys]

token_bucket = TokenBucket(Config.API_RATE_LIMIT)
