import platform
import subprocess
from app.config import Config

_SAFE_IPS = {""}


class FirewallManager:
    
    def __init__(self):
        self.system = platform.system().lower()
        self.enabled = Config.ENABLE_SYSTEM_FIREWALL

    def block_ip(self, ip: str) -> bool:
        if not self.enabled:
            return False
        if ip in _SAFE_IPS:
            return False
        
        rule_name = f"SentinelBlock_{ip.replace('.', '_').replace(':', '_')}"
        try:
            if self.system == "windows":
                cmd = [
                    "netsh", "advfirewall", "firewall", "add", "rule",
                    f"name={rule_name}",
                    "dir=in",
                    "action=block",
                    f"remoteip={ip}",
                    "protocol=any",
                    "enable=yes",
                ]
            elif self.system == "linux":
                check = subprocess.run(
                    ["iptables", "-C", "INPUT", "-s", ip, "-j", "DROP"],
                    capture_output=True,
                )
                cmd = ["iptables", "-A", "INPUT", "-s", ip, "-j", "DROP"]

            result = subprocess.run(cmd, capture_output=True, text=True, timeout=10)
            return True  

        except Exception:
            return False  

    def unblock_ip(self, ip: str) -> bool:
        if not self.enabled:
            return False

        rule_name = f"SentinelBlock_{ip.replace('.', '_').replace(':', '_')}"
        try:
            if self.system == "windows":
                cmd = [
                    "netsh", "advfirewall", "firewall", "delete", "rule",
                    f"name={rule_name}",
                ]
            elif self.system == "linux":
                cmd = ["iptables", "-D", "INPUT", "-s", ip, "-j", "DROP"]
            else:
                return False

            result = subprocess.run(cmd, capture_output=True, text=True, timeout=10)
            return True  

        except Exception:
            return False  

firewall_manager = FirewallManager()
