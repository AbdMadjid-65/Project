import redis
import time
from app.config import Config

# this file used to connect to the redis or if it is not available use MockRedis 
# redis store number of remaning request for each user and ban data 
class MockRedis:
    def __init__(self):
        self._hashes = {} # is like small box store number of reaest of each user and is the user banned ? 
        self._strings = {}  
        self._expires = {} # the time each key expire 

    def _check_expiry(self, key): # cheek if the key is exprired then delete it from the redis 
        if key in self._expires:
            if time.time() > self._expires[key]:
                self.delete(key)
                return True
        return False

    def hgetall(self, key):  # to read the whole hash
        self._check_expiry(key)
        return dict(self._hashes.get(key, {}))

    def hmset(self, key, mapping): # to create hash or update it 
        self._check_expiry(key)
        if key not in self._hashes:
            self._hashes[key] = {}
        self._hashes[key].update({str(k): str(v) for k, v in mapping.items()})

    def hget(self, key, field): # to read single value from the hash
        self._check_expiry(key)
        return self._hashes.get(key, {}).get(field)

    def get(self, key):
        self._check_expiry(key)
        return self._strings.get(key)

    def set(self, key, value, ex=None):
        self._strings[key] = str(value)
        if ex:
             self.expire(key, ex)

    def incr(self, key):
        self._check_expiry(key)
        val = int(self._strings.get(key, 0)) + 1
        self._strings[key] = str(val)
        return val

    def delete(self, *keys):
        for k in keys:
            self._hashes.pop(k, None)
            self._strings.pop(k, None)
            self._expires.pop(k, None)

    def exists(self, key):
        self._check_expiry(key)
        return key in self._hashes or key in self._strings

    def keys(self, pattern="*"):
        # Cleanup expired keys first
        for k in list(self._expires.keys()):
            self._check_expiry(k)
            
        all_keys = set(self._hashes.keys()) | set(self._strings.keys())
        if pattern == "*":
            return list(all_keys)
        prefix = pattern.rstrip("*")
        return [k for k in all_keys if k.startswith(prefix)]

    def ttl(self, key): # we dont store data parmenently some data we delete it after short period 
        self._check_expiry(key)
        if key not in self._strings and key not in self._hashes:
             return -2
        if key not in self._expires:
             return -1
        return int(self._expires[key] - time.time())

    def expire(self, key, seconds):
        if self.exists(key):
             self._expires[key] = time.time() + seconds 

    def ping(self):
        return True

    def eval(self, script, numkeys, *args):
        return None


def create_redis_connection(): # To create redis connection 
    try:
        conn = redis.Redis.from_url(Config.REDIS_URL, decode_responses=True)
        conn.ping()
        print("Connected to Redis")
        return conn
    except Exception:
        print("Redis not available — using in-memory MockRedis")
        return MockRedis()


redis_conn = create_redis_connection() # any part of the app want to access to the redis use this object 
