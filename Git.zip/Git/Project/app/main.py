import os
from app.config import Config

from fastapi import FastAPI, WebSocket, WebSocketDisconnect, Request, Form
from fastapi.responses import FileResponse, JSONResponse, RedirectResponse
from fastapi.staticfiles import StaticFiles

from app.middleware.rate_limiter import RateLimiterMiddleware
from app.dashboard.websocket import ws_manager
from app.services.token_bucket import token_bucket

USERNAME=Config.USERNAME
PASSWORD=Config.PASSWORD

app = FastAPI(
    title="CICONIX DoS",
    description="Application-Layer DoS Mitigation System",
)

static_dir = os.path.join("static")

app.mount("/static", StaticFiles(directory=static_dir), name="static")

app.add_middleware(RateLimiterMiddleware, broadcast_fn=ws_manager.broadcast) # Each request passes through this first to check if the client is allowed or temporarily banned



@app.get("/login")
async def login_page():
    return FileResponse(os.path.join(static_dir, "login/login.html"))


@app.post("/login")
async def login(username: str = Form(...), password: str = Form(...)):
    if username == USERNAME and password == PASSWORD:
        response = RedirectResponse(url="/", status_code=302)
        response.set_cookie(key="authenticated", value="true")
        return response
    else:
        return JSONResponse(
            status_code=401,
            content={"error": "Invalid username or password"}
        )
        
@app.get("/")
async def dashboard(request: Request):
    auth = request.cookies.get("authenticated")
    if auth != "true":
        return RedirectResponse(url="/login")
    return FileResponse(os.path.join(static_dir, "dashboard/dashboard.html"))


@app.websocket("/ws/stats")
async def websocket_endpoint(websocket: WebSocket):
    await ws_manager.connect(websocket)
    try:
        while True:
            await websocket.receive_text()
    except WebSocketDisconnect:
        ws_manager.disconnect(websocket)
    except Exception:
        ws_manager.disconnect(websocket)

@app.get("/api/stats")
async def get_stats():
    bans = token_bucket.get_all_bans()
    return {
        "active_dashboard_clients": ws_manager.count,
        "active_bans": len(bans),
        "banned_keys": bans,
    }


@app.get("/api/bans")
async def get_bans():
    return FileResponse(os.path.join(static_dir, "bannedlist/bannedlist.html"))
    #return {"bans": token_bucket.get_all_bans()}


@app.post("/api/unban/{key}")
async def unban(key: str):
    token_bucket.unban(key)
    return {"status": "unbanned", "key": key}

@app.get("/api/ping")
async def api_ping():
    return {"message": "pong", "shield": "active"}


@app.get("/page")
async def page():
    return FileResponse(os.path.join(static_dir, "page.html"))