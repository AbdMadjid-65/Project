class Config:

    DEBUG = "true"
    PORT = 5000

    REDIS_URL = "redis://localhost:6379/0"
    
    SECRET_KEY="CICONIX"
    
    USERNAME = "CICONIX"
    PASSWORD = "CICONIX"

    CAPACITY = 20
    RATE = 2
    TIME_WINDOW = 60

    API_RATE_LIMIT = 10 
    BROWSER_RATE_LIMIT = 20

    BAN_DURATION = 5
    BAN_THRESHOLD = 5
    BAN_DURATIONS = [5, 10, 15, 20] 
    
    ENABLE_SYSTEM_FIREWALL = true